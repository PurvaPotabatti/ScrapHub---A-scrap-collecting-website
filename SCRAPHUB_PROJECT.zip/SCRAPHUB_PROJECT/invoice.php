<?php
session_start();
$con = mysqli_connect("localhost", "root", "", "test");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Invoice</title>
    <link rel="stylesheet" href="css/Invoice.css">
</head>
<body>
    <div class="container invoice">
        <div class="invoice-header">
            <div class="ui left aligned grid">
                <div class="row">
                    <div class="left floated left aligned six wide column">
                        <div class="ui">
                            <h1 class="ui header pageTitle">ScrapHub <small class="ui sub header">Invoice</small></h1>
                            <h4 class="ui sub header invDetails">NO: <?php echo $_SESSION['id'];?> | Date: <?php echo date('m/d/Y');?></h4>
                        </div>
                    </div>
                    <div class="right floated left aligned six wide column">
                        <div class="ui">
                            <div class="column two wide right floated">
                                <img class="logo" src="img/logo.jpeg" />
                                <!--<ul class="">
                                    <li><strong>RCJA Australia</strong></li>
                                    <li>Lorem Ipsum</li>
                                    <li>2 Alliance Lane VIC</li>
                                    <li>info@rcja.com</li>
                                </ul>-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="ui segment cards">
            <div class="ui card">
                <div class="content">
                    <div class="header">Company Details</div>
                </div>
                <div class="content">
                    <ul>
                        <li><strong> Name:ScrapHub </strong></li>
                        <li><strong> Address: </strong> GP, Solapur</li>
                        <li><strong> Phone: </strong> (+61)404123123</li>
                        <li><strong> Email: </strong> scraphub@123.com</li>
                        <li><strong> Contact: </strong> Rishita Gojgekar</li>
                    </ul>
                </div>
            </div>
            <div class="ui card customercard">
                <div class="content">
                    <div class="header">Customer Details</div>
                </div>
                <div class="content">
                    <ul>
                        <li><strong> Name: <?php echo $_SESSION['user_name'];?> </strong></li>
                        <li><strong> Address: </strong> <?php echo $_SESSION['address'];?></li>
                        <li><strong> Phone: </strong> <?php echo $_SESSION['mobile_number'];?></li>
                        <li><strong> Email: </strong> <?php echo $_SESSION['email_id'];?></li><br>
						<li><strong> Pickup Date </strong> <?php echo $_SESSION['date'];?></li><br>
						<li><strong> Scrap to be selled : </strong></li>
                    </ul>
                </div>
								
				<div class="content">
                <table id="itemTable" class="ui celled table">
                    <thead>
                        <tr>
                            <th>Scrap Item</th>
                            <th class="text-center colfix">Price</th>
                            <th class="text-center colfix">Quantity</th>
                            <th class="text-center colfix">Scrap image</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
						$scrap_total = 0;
                          $select_query2 = "SELECT * FROM `user_orders` WHERE order_id='{$_SESSION['id']}'";
                $order_result = mysqli_query($con, $select_query2);
                if($order_result) {
                    while($order_fetch = mysqli_fetch_assoc($order_result))
                {
                    $scrap_total = $scrap_total + ($order_fetch['price'] * $order_fetch['quantity']); // Quote array keys
                    $image_name = $order_fetch['file']; // Assuming 'file' is the column name for the image name
                    $image_path = "images/$image_name"; // Assuming images are stored in 'images' folder
                    echo "
                    <tr>
                        <td>$order_fetch[scrap_name]</td>
                        <td>$order_fetch[price]</td>
                        <td>$order_fetch[quantity]</td> 
                        <td><img src='$image_path' alt='Image' style='width:50px; height:50px' ></td>                 
                    </tr>
                    ";
                }

                } else {
                    echo "Error in fetching orders: " . mysqli_error($con);
                }?>
                    </tbody>
                </table><br>
                    <div id="totalAmount">
					<?php echo "Total scrap amount = ".$scrap_total; ?>
					</div>
                </div>
				
				
				<div class="content">
                    <ul>
                        <li><strong> Item to be swapped with : </strong></li>
                    </ul>
					<table id="itemTable" class="ui celled table">
                    <thead>
                        <tr>
                            <th>Item Name</th>
                            <th class="text-center colfix">Price</th>
                            <th class="text-center colfix">Quantity</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
						  $item_total = 0;
                          $select_query3 = "SELECT * FROM `item_exchange` WHERE item_id='{$_SESSION['id']}'";
                $item_result = mysqli_query($con, $select_query3);
                if($item_result) {
                    while($item_fetch = mysqli_fetch_assoc($item_result))
                {
					$item_total = $item_total + ($item_fetch['item_price'] * $item_fetch['item_quantity']); // Quote array keys
                   echo "
                    <tr>
                        <td>$item_fetch[item_name]</td>
                        <td>$item_fetch[item_price]</td>
                        <td>$item_fetch[item_quantity]</td> 
                    </tr>
                    ";
                }

                } else {
                    echo "Error in fetching orders: " . mysqli_error($con);
                }?>
                    </tbody>
                </table><br>
				<div id="totalAmount">
					<?php echo "Total swap with item amount = ".$item_total; ?>
					</div>
                 
                </div>
				
            </div>

            
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</body>
</html>
                   
