<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_name']) || !isset($_SESSION['mobile_number']) || !isset($_SESSION['email_id'])) {
    echo "<script>
    if(confirm('Please login to continue.')) {
        window.location.href = 'cpp_login_demo.php';
    }
    </script>";
    exit;
}

// Establish database connection
$con = mysqli_connect("localhost", "root", "", "test");

if(mysqli_connect_error()) {
    error_log("Failed to connect to database: " . mysqli_connect_error());
    echo "<script>
          alert('Cannot connect to db');
          window.location.href='add_to_cart_demo.php';
          </script>";
    exit();
}

// Retrieve user ID from the database using login credentials
$user_name = $_SESSION['user_name'];
$mobile_number = $_SESSION['mobile_number'];
$email_id = $_SESSION['email_id'];

$query = "SELECT id FROM order_manager WHERE username = '$user_name' AND mobile_no = '$mobile_number' AND email = '$email_id'";
$result = mysqli_query($con, $query);

// Check if query was successful
if ($result && mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $user_id = $row['id'];
} else {
    echo "<script>
          alert('Failed to retrieve user ID from the database');
          window.location.href='cpp_login_demo.php';
          </script>";
    exit();
}

// Retrieve scrap items for the user from the database
$query = "SELECT * FROM user_orders WHERE order_id = '$user_id'";
$result = mysqli_query($con, $query);

// Check if query was successful
if ($result) {
    $scrap_items = array();
    // Fetch data and store in session
    while ($row = mysqli_fetch_assoc($result)) {
        $scrap_items[] = $row;
    }
    $_SESSION['scrap_items'] = $scrap_items;
} else {
    echo "<script>
          alert('Failed to retrieve scrap items from the database');
          window.location.href='categories_demo.php';
          </script>";
    exit();
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $upload_successful = true;
    
    // Iterate through each scrap item and process the uploaded images
    foreach ($_SESSION['scrap_items'] as $value) {
        $scrap_name = $value['scrap_name'];
        
        // Check if an image was uploaded for this scrap item
        if (isset($_FILES[$scrap_name])) {
            $target_dir = "images/"; // Specify the directory where you want to store the files
            $file_name = basename($_FILES[$scrap_name]['name']);
            $target_file = $target_dir . $file_name;

            // Move the uploaded file to the target directory
            if (move_uploaded_file($_FILES[$scrap_name]['tmp_name'], $target_file)) {
                // Insert the image file name into the database
                $insert_query = "UPDATE `user_orders` SET `file` = '$file_name' WHERE `order_id` = '$user_id' AND `scrap_name` = '$scrap_name'";
                
                if (!mysqli_query($con, $insert_query)) {
                    error_log("MySQL error: " . mysqli_error($con));
                    $upload_successful = false;
                    break; // Exit loop if one upload fails
                }
            } else {
                $upload_successful = false;
                break; // Exit loop if one upload fails
            }
        }
    }
    
    // Display success or failure alert
    if ($upload_successful) {
echo "<script>
            var confirmation = confirm('Exchange your scrap with item?');
            if (confirmation) {
                window.location.href = 'item_exchange_demo.php';
            } else {
                window.location.href = 'schedule.php';
            }
          </script>";
    } else {
        echo "<script>alert('Failed to insert all images');</script>";
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Upload Scrap Images</title>
<link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css'>
<style>
       body {
            background-color: #f8f9fa;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px 0px rgba(0,0,0,0.1);
            margin-top: 50px;
        }
        h2 {
            color: #6ab04c; /* Grass green color */
            margin-bottom: 20px;
        }
        form {
            margin-top: 20px;
        }
        .back-icon {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1000;
            font-size: 24px;
            color: #6ab04c; /* Grass green color */
            text-decoration: none;
            transition: transform 0.3s ease-in-out;
        }
        .back-icon:hover {
            transform: scale(1.1);
        }
        .form-group {
            margin-bottom: 20px;
        }
        .btn-primary {
            background-color: #6ab04c; /* Grass green color */
            border-color: #6ab04c; /* Grass green color */
        }
        .btn-primary:hover {
            background-color: #5d9942; /* Darker shade of grass green */
            border-color: #5d9942; /* Darker shade of grass green */
        }
    </style>
</head>
<body>
     <!-- Back Navigation Icon -->
     <a href="categories_demo.php" class="back-icon" style="text-decoration: none;">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
            <path fill="#6ab04c" d="M20.485 11H4.207l5.147-5.146a.999.999 0 1 0-1.414-1.415l-7 7a.999.999 0 0 0 0 1.415l7 7a.997.997 0 0 0 1.414 0 .999.999 0 0 0 0-1.415L4.207 13h16.278a1 1 0 0 0 0-2z"/>
        </svg>
    </a>
<div class="container mt-5">
    <h2 class="mb-4">Upload Images for Selected Scrap Items</h2>
    <form method="POST" action="" enctype="multipart/form-data">
        <?php
        // Iterate through each scrap item and create an input file field for each
        foreach ($_SESSION['scrap_items'] as $value) {
            $scrap_name = $value['scrap_name'];
            echo "<div class='form-group'>";
            echo "<label for='$scrap_name'>$scrap_name:</label>";
            echo "<input type='file' class='form-control-file' name='$scrap_name' accept='image/*'>";
            echo "</div>";
        }
        ?>
        <button type="submit" class="btn btn-primary">Upload Images</button>
    </form>
</div>
</body>
</html>
