<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Schedule Pick Up</title>
    <link rel="stylesheet" href="css/schedule.css">
	<style>
	.btn.schedule-btn {
    /* Define your styles here */
    background-color: #03AC13; /* Green */
    border: none;
    color: white;
    padding: 15px 0; /* Adjust padding as needed */
    text-align: center;
    text-decoration: none;
    display: block;
    width: 100%; /* Stretch the button to fit container width */
    font-size: 16px;
    cursor: pointer;
    border-radius: 10px;
    box-sizing: border-box; /* Include padding and border in the width */
}

	</style>
</head>
<body>
    <div class="container">
        <h1>Pick Up Schedule</h1>
        <form action="#" method="POST" onsubmit="return showSuccessAlert()">
            <!--<div class="form-group">
                <label for="name">Email Address</label>
                <input type="email" id="email" name="t2" required>
            </div>-->
            <div class="form-group">
                <label for="address">Address:</label>
                <input type="text" id="address" name="t3" required>
            </div>
            <div class="form-group">
                <label for="date">Pick Up Date:</label>
                <input type="date" id="date" name="t4" required>
            </div>
            <!--<div class="form-group">
                <label for="time">Pick Up Time:</label>
                <input type="time" id="time" name="t5" required>
            </div>-->
            
            <input type="submit" class="btn schedule-btn" value="Schedule Pick Up" name="submit"/>
        </form>
    </div>
    <?php
	session_start();
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "test";

    // Create connection
    $conn = mysqli_connect($servername, $username, $password, $dbname);

    // Check connection
    if (!$conn) 
	{
        die("Connection failed: " . mysqli_connect_error());
    }

    if(isset($_POST['submit'])) {
    //$email = $_POST['t2'];
    $address = $_POST['t3'];
	$_SESSION['address']=$address;
    $date = $_POST['t4'];
	$_SESSION['date']=$date;
    $schedule_id = $_SESSION['id'];

    // Use prepared statements to prevent SQL injection
    $sql = "INSERT INTO `schedule`(`schedule_id`, `address`, `date`) VALUES (?, ?, ?)";
    $stmt = mysqli_prepare($conn, $sql);

    if ($stmt) 
	{
        mysqli_stmt_bind_param($stmt, "iss", $schedule_id, $address, $date);
        if (mysqli_stmt_execute($stmt)) 
		{
             echo "<script>
                 window.location.href='invoice.php';
             </script>";
        } 
		else 
		{
            echo "Error: " . mysqli_error($conn);
        }
    } 
	else 
	{
        echo "Error: " . mysqli_error($conn);
    }
}


    ?>
</body>
</html>

<script>
function showSuccessAlert() {
    alert("New record inserted successfully!");
    return true; // Allow form submission
}
</script>
